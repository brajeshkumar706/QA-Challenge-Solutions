require "watir"
require "cucumber"

Given(/^launch browser$/) do
    @browser = Watir::Browser.new :firefox
end
And(/^navigate to facebook$/) do
    @browser.goto "https://facebook.com"
end

When(/^username box is displayed$/) do
    @browser.text_field(:name => "email").click
end
        
And(/^we type the username$/) do
    @browser.text_field(:name => "email").set ("Enter your UserName")
end

Then (/^click on the password box$/) do
    @browser.text_field(:name => "pass").click
end
        
And (/^type the passwword as arsha$/) do
    @browser.text_field(:id => "pass").set ("Enter Your own password")
end

And (/^click on the login button$/) do
    @browser.button(:id => "u_0_2").click
	@browser.link(:text => "Messenger").click
end